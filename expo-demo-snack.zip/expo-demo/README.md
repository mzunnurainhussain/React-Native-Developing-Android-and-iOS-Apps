
# Expo Demo Snack

A minimal React Native (Expo) demo designed to be opened directly in **Snack** or **Expo Go**. It shows:
- Multi-screen UI without external navigation libs (simple state-based tabs)
- A **FlatList** with load-more (infinite scroll simulation)
- **AsyncStorage** for persisting tasks
- **Long press** to delete
- Simple **Theme (light/dark)** using React Context
- Basic **fetch()** to JSONPlaceholder for demo content

## Quick Start (Snack)
1. Go to https://snack.expo.dev
2. Click **Import GitHub** and paste your GitHub repo URL (after you push this project), **or** drag-and-drop this folder/ZIP into Snack.
3. Snack will install dependencies automatically. Click **Run**. Scan the QR code with the **Expo Go** app.

## Quick Start (Local Expo)
```bash
npm install
npm run start
# then press 'a' for Android emulator, 'i' for iOS simulator, or open Expo Go and scan the QR.
```

## Files
- `App.js` — all UI
- `package.json` — dependencies (Expo SDK 51)
- `app.json` — Expo config
- `assets/icon.png` — app icon placeholder

## Notes
- Internet is used to fetch demo todos from JSONPlaceholder. If offline, the app still works (Tasks tab uses local storage).
- Keep it simple for reviewers; this project is Snack-friendly (single app file, limited deps).
