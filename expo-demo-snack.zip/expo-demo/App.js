
import React, { useEffect, useMemo, useState, createContext, useContext } from 'react';
import { SafeAreaView, View, Text, FlatList, TouchableOpacity, TextInput, Alert, StatusBar, ActivityIndicator, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * Simple Theme Context
 */
const ThemeContext = createContext();
const useTheme = () => useContext(ThemeContext);

export default function App() {
  const [tab, setTab] = useState('Home');
  const [theme, setTheme] = useState('light');
  const value = useMemo(() => ({ theme, toggle: () => setTheme(t => (t === 'light' ? 'dark' : 'light')) }), [theme]);

  const bg = theme === 'light' ? '#ffffff' : '#0b1220';
  const fg = theme === 'light' ? '#111827' : '#e5e7eb';
  const card = theme === 'light' ? '#f3f4f6' : '#111827';
  const brand = '#3478F6';

  return (
    <ThemeContext.Provider value={value}>
      <SafeAreaView style={[styles.safe, { backgroundColor: bg }]}>
        <StatusBar barStyle={theme === 'light' ? 'dark-content' : 'light-content'} />
        <Header title="Expo Demo Snack" onToggleTheme={value.toggle} theme={theme} />
        <Tabs active={tab} setActive={setTab} brand={brand} fg={fg} bg={bg} />
        <View style={[styles.content, { backgroundColor: bg }]}>
          {tab === 'Home' && <HomeScreen fg={fg} card={card} />}
          {tab === 'Tasks' && <TasksScreen fg={fg} card={card} />}
          {tab === 'Settings' && <SettingsScreen fg={fg} card={card} />}
        </View>
      </SafeAreaView>
    </ThemeContext.Provider>
  );
}

function Header({ title, onToggleTheme, theme }) {
  return (
    <View style={styles.header}>
      <Text style={styles.headerTitle}>{title}</Text>
      <TouchableOpacity style={styles.headerBtn} onPress={onToggleTheme}>
        <Text style={styles.headerBtnText}>{theme === 'light' ? '🌙' : '☀️'}</Text>
      </TouchableOpacity>
    </View>
  );
}

function Tabs({ active, setActive, brand, fg, bg }) {
  const tabs = ['Home', 'Tasks', 'Settings'];
  return (
    <View style={styles.tabs}>
      {tabs.map(t => (
        <TouchableOpacity key={t} style={[styles.tabBtn, active === t && { borderBottomColor: brand, borderBottomWidth: 3 }]} onPress={() => setActive(t)}>
          <Text style={[styles.tabText, { color: active === t ? brand : '#6b7280' }]}>{t}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

function HomeScreen({ fg, card }) {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [page, setPage] = useState(1);

  const load = async (next=false) => {
    try {
      setLoading(true);
      const p = next ? page + 1 : 1;
      const res = await fetch(`https://jsonplaceholder.typicode.com/todos?_limit=10&_page=${p}`);
      const json = await res.json();
      setData(next ? [...data, ...json] : json);
      setPage(p);
    } catch (e) {
      Alert.alert('Network error', 'Could not fetch demo items.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(false); }, []);

  const renderItem = ({ item }) => (
    <View style={[styles.card, { backgroundColor: card }]}>
      <Text style={[styles.cardTitle]} numberOfLines={1}>{item.title}</Text>
      <Text style={{ color: item.completed ? '#10b981' : '#ef4444' }}>
        {item.completed ? 'Done' : 'Pending'}
      </Text>
    </View>
  );

  return (
    <View style={styles.screen}>
      <View style={styles.rowBetween}>
        <Text style={[styles.sectionTitle, { color: fg }]}>Home (Fetch demo)</Text>
        <TouchableOpacity style={styles.smallBtn} onPress={() => load(false)}>
          <Text style={styles.smallBtnText}>Refresh</Text>
        </TouchableOpacity>
      </View>

      {loading && data.length === 0 ? <ActivityIndicator /> :
        <FlatList
          data={data}
          keyExtractor={item => String(item.id)}
          renderItem={renderItem}
          onEndReached={() => load(true)}
          onEndReachedThreshold={0.4}
          ListFooterComponent={loading ? <ActivityIndicator /> : null}
        />
      }
    </View>
  );
}

function TasksScreen({ fg, card }) {
  const [text, setText] = useState('');
  const [tasks, setTasks] = useState([]);

  useEffect(() => { (async () => {
    const raw = await AsyncStorage.getItem('@tasks');
    if (raw) setTasks(JSON.parse(raw));
  })(); }, []);

  useEffect(() => { AsyncStorage.setItem('@tasks', JSON.stringify(tasks)); }, [tasks]);

  const add = () => {
    if (!text.trim()) return;
    setTasks(prev => [{ id: Date.now(), title: text.trim() }, ...prev]);
    setText('');
  };

  const remove = (id) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  const renderItem = ({ item }) => (
    <TouchableOpacity onLongPress={() => remove(item.id)} delayLongPress={800}>
      <View style={[styles.card, { backgroundColor: card }]}>
        <Text style={styles.cardTitle}>{item.title}</Text>
        <Text style={{ color: '#6b7280' }}>long-press to delete</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.screen}>
      <Text style={[styles.sectionTitle, { color: fg }]}>Tasks (AsyncStorage)</Text>
      <View style={styles.row}>
        <TextInput
          style={styles.input}
          placeholder="Add a task…"
          value={text}
          onChangeText={setText}
          onSubmitEditing={add}
          returnKeyType="done"
        />
        <TouchableOpacity style={styles.addBtn} onPress={add}>
          <Text style={styles.addBtnText}>Add</Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={tasks}
        keyExtractor={item => String(item.id)}
        renderItem={renderItem}
        ListEmptyComponent={<Text style={{ color: '#6b7280', marginTop: 12 }}>No tasks yet.</Text>}
      />
    </View>
  );
}

function SettingsScreen({ fg, card }) {
  const { theme, toggle } = useTheme();
  return (
    <View style={styles.screen}>
      <Text style={[styles.sectionTitle, { color: fg }]}>Settings</Text>
      <View style={[styles.card, { backgroundColor: card }]}>
        <Text style={styles.cardTitle}>Theme</Text>
        <Text style={{ color: '#6b7280', marginBottom: 8 }}>Current: {theme}</Text>
        <TouchableOpacity style={styles.smallBtn} onPress={toggle}>
          <Text style={styles.smallBtnText}>Toggle Theme</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12 },
  headerTitle: { fontSize: 18, fontWeight: '700' },
  headerBtn: { padding: 8 },
  headerBtnText: { fontSize: 18 },
  tabs: { flexDirection: 'row', paddingHorizontal: 8, borderBottomColor: '#e5e7eb', borderBottomWidth: 1 },
  tabBtn: { paddingVertical: 10, paddingHorizontal: 16 },
  tabText: { fontSize: 14, fontWeight: '600' },
  content: { flex: 1, padding: 16 },
  screen: { flex: 1 },
  sectionTitle: { fontSize: 16, fontWeight: '700', marginBottom: 8 },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  row: { flexDirection: 'row', gap: 8, alignItems: 'center', marginBottom: 8 },
  input: { flex: 1, borderWidth: 1, borderColor: '#e5e7eb', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10 },
  addBtn: { backgroundColor: '#3478F6', paddingHorizontal: 14, paddingVertical: 10, borderRadius: 8 },
  addBtnText: { color: 'white', fontWeight: '700' },
  smallBtn: { backgroundColor: '#111827', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8 },
  smallBtnText: { color: 'white', fontWeight: '700' },
  card: { padding: 14, borderRadius: 12, marginBottom: 10 },
  cardTitle: { fontSize: 15, fontWeight: '700', marginBottom: 4 },
});
